//Websocket configuration
var webSocket = new WebSocket("ws://localhost:8080/BabylonRTS/websocketendpoint");
webSocket.onopen = function(){ wsOpen();};
webSocket.onclose = function(){ wsClose();};
webSocket.onmessage = function(message){ wsGetMessage(message);};
webSocket.onerror = function(){ wsError();};
	
function wsOpen(){
}

function wsClose(){
}

function wsCloseConnection(){
	webSocket.close();
}

function wsSendMessage(message){
	webSocket.send(message);
}

function wsGetMessage(message){
}

function wsError(){
	alert("websocket error");
}
