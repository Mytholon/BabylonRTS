package player;

import org.json.JSONObject;

public class Unit {
	
	//Class variables
	private JSONObject position;
	private String type;
	private int life;
	private int playerID;
	private boolean idle;
	
	// Counter of this class instances
	public static int instanceCounter = 0;
	
	//Contructor of class Unit
	public Unit() {
		instanceCounter++;
	}
}
