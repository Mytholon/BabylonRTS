package player;

import java.io.Serializable;

public class Player implements Serializable  {

	// Class variables
	private int playerId;
	private int enemyID;
	private int maxLife;
	private int life;
	private int resource1;
	private int resource2;
	private int workerCount;
	private int unitCount;
	private int unitType1Count;
	private int unitType2Count;
	private int unitType3Count;
	private int barrackCount;
	private int unitsLost;
	private int barracksLost;
	private boolean getsAttacked;
	private boolean isAttacking;
	private boolean isAI;
	private boolean hasCBR;
	
	private int enemyLife;
	private int enemyWorkerCount;
	private int enemyUnitCount;
	private int enemyUnitType1Count;
	private int enemyUnitType2Count;
	private int enemyUnitType3Count;
	private int enemyBarrackCount;
	
	// Constructor for class Player
	public Player(int playerId, int enemyID, int life, int resource1, int resource2, 
			int workerCount, int unitCount, int unitType1Count, int unitType2Count, int unitType3Count, 
			int barrackCount, int unitsLost, int barracksLost, boolean getsAttacked, boolean isAttacking,
			boolean isAI, boolean hasCBR,
			int enemyLife, int enemyWorkerCount, int enemyUnitCount, int enemyUnitType1Count, 
			int enemyUnitType2Count, int enemyUnitType3Count, int enemyBarrackCount) {
		
		this.playerId = playerId;
		this.enemyID = enemyID;
		this.life = life;
		this.resource1 = resource1;
		this.resource2 = resource2;
		this.workerCount = workerCount;
		this.unitCount = unitCount;
		this.unitType1Count = unitType1Count;
		this.unitType2Count = unitType2Count;
		this.unitType3Count = unitType3Count;
		this.barrackCount = barrackCount;
		this.unitsLost = unitsLost;
		this.barracksLost = barracksLost;
		this.getsAttacked = getsAttacked;
		this.isAttacking = isAttacking;
		this.isAI = isAI;
		this.hasCBR = hasCBR;
		
		this.enemyLife = enemyLife;
		this.enemyWorkerCount = enemyWorkerCount;
		this.enemyUnitCount = enemyUnitCount;
		this.enemyUnitType1Count = enemyUnitType1Count;
		this.enemyUnitType2Count = enemyUnitType2Count;
		this.enemyUnitType3Count = enemyUnitType3Count;
		this.enemyBarrackCount = enemyBarrackCount;
	}
	
	//Constructor for enemy 
//	public Player(int workerCount, int unitCount, int barrackCount) {
//		this.workerCount = workerCount;
//		this.unitCount = unitCount;
//		this.barrackCount = barrackCount;
//	}

	//Getter & Setter for attributes
	public int getEnemyID() {
		return enemyID;
	}

	public void setEnemyID(int enemyID) {
		this.enemyID = enemyID;
	}

	public int getResource1() {
		return resource1;
	}

	public void setResource1(int resource1) {
		this.resource1 = resource1;
	}

	public int getResource2() {
		return resource2;
	}

	public void setResource2(int resource2) {
		this.resource2 = resource2;
	}

	public int getWorkerCount() {
		return workerCount;
	}

	public void setWorkerCount(int workerCount) {
		this.workerCount = workerCount;
	}

	public int getBarrackCount() {
		return barrackCount;
	}

	public void setBarrackCount(int barrackCount) {
		this.barrackCount = barrackCount;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getUnitCount() {
		return unitCount;
	}

	public void setUnitCount(int unitCount) {
		this.unitCount = unitCount;
	}
	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public int getMaxLife() {
		return maxLife;
	}

	public void setMaxLife(int maxLife) {
		this.maxLife = maxLife;
	}

	public int getUnitType1Count() {
		return unitType1Count;
	}

	public void setUnitType1Count(int unitType1Count) {
		this.unitType1Count = unitType1Count;
	}

	public int getUnitType2Count() {
		return unitType2Count;
	}

	public void setUnitType2Count(int unitType2Count) {
		this.unitType2Count = unitType2Count;
	}

	public int getUnitType3Count() {
		return unitType3Count;
	}

	public void setUnitType3Count(int unitType3Count) {
		this.unitType3Count = unitType3Count;
	}

	public int getUnitsLost() {
		return unitsLost;
	}

	public void setUnitsLost(int lostUnits) {
		this.unitsLost = lostUnits;
	}

	public int getBarracksLost() {
		return barracksLost;
	}

	public void setBarracksLost(int lostBarracks) {
		this.barracksLost = lostBarracks;
	}

	public boolean isGetsAttacked() {
		return getsAttacked;
	}

	public void setGetsAttacked(boolean getsAttacked) {
		this.getsAttacked = getsAttacked;
	}

	public boolean isAttacking() {
		return isAttacking;
	}

	public void setAttacking(boolean isAttacking) {
		this.isAttacking = isAttacking;
	}

	public boolean isAI() {
		return isAI;
	}

	public void setAI(boolean isAI) {
		this.isAI = isAI;
	}

	public boolean getHasCBR() {
		return hasCBR;
	}

	public void setHasCBR(boolean hasCBR) {
		this.hasCBR = hasCBR;
	}

	public int getEnemyLife() {
		return enemyLife;
	}

	public void setEnemyLife(int enemyLife) {
		this.enemyLife = enemyLife;
	}

	public int getEnemyWorkerCount() {
		return enemyWorkerCount;
	}

	public void setEnemyWorkerCount(int enemyWorkerCount) {
		this.enemyWorkerCount = enemyWorkerCount;
	}

	public int getEnemyUnitCount() {
		return enemyUnitCount;
	}

	public void setEnemyUnitCount(int enemyUnitCount) {
		this.enemyUnitCount = enemyUnitCount;
	}

	public int getEnemyUnitType1Count() {
		return enemyUnitType1Count;
	}

	public void setEnemyUnitType1Count(int enemyUnitType1Count) {
		this.enemyUnitType1Count = enemyUnitType1Count;
	}

	public int getEnemyUnitType2Count() {
		return enemyUnitType2Count;
	}

	public void setEnemyUnitType2Count(int enemyUnitType2Count) {
		this.enemyUnitType2Count = enemyUnitType2Count;
	}

	public int getEnemyUnitType3Count() {
		return enemyUnitType3Count;
	}

	public void setEnemyUnitType3Count(int enemyUnitType3Count) {
		this.enemyUnitType3Count = enemyUnitType3Count;
	}

	public int getEnemyBarrackCount() {
		return enemyBarrackCount;
	}

	public void setEnemyBarrackCount(int enemyBarrackCount) {
		this.enemyBarrackCount = enemyBarrackCount;
	}
	
}
