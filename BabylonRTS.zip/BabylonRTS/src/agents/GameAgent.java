package agents;

import java.io.IOException;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.util.leap.Properties;
import jade.wrapper.gateway.JadeGateway;

@ServerEndpoint("/websocketendpoint")
public class GameAgent extends Agent {

	private static Session session;
	
	@OnOpen
	public void onOpen(Session session){
		System.out.println("Open Connection");
		GameAgent.session = session;
	}
	
	@OnClose
	public void onClose(){
		System.out.println("Close Connection");
	}
	
	@OnMessage
	public void onMessage(String message) throws InterruptedException, IOException {
		try {
			//JadeGateway.init(Agent.class.getName(), new Properties());
			JadeGateway.execute(new OneShotBehaviour() {
				public void action() {
					ACLMessage msgSend = new ACLMessage(ACLMessage.INFORM);
					msgSend.setContent(message);
					msgSend.addReceiver(new AID("Updater", AID.ISLOCALNAME));
					myAgent.send(msgSend);
  				}
			});
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		//return message;
	}

	@OnError
	public void onError(Throwable e){
		e.printStackTrace();
	}
	
	protected void setup() {

		addBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				ACLMessage msgReceive = myAgent.receive();
				
				if(msgReceive != null && msgReceive.getContent() != null) {
					System.out.println(getLocalName() + " received " + msgReceive.getContent());
					try {
						//Send message to webSocket eventlistener
						session.getBasicRemote().sendText(msgReceive.getContent());
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					block();
				}
			}
		});
	}
}