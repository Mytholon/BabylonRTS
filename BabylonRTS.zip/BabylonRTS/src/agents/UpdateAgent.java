package agents;

import java.io.IOException;

import org.json.JSONObject;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import player.Player;

public class UpdateAgent extends Agent {

	protected void setup() {

		addBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				final ACLMessage msgSend = new ACLMessage(ACLMessage.INFORM); // sending message
				final ACLMessage msgReceive = receive(); // receiving message
				Player agentPlayer1 = null;
				Player agentPlayer2 = null;

				// check if message is not null
				if (msgReceive != null && msgReceive.getContent() != null) {

					System.out.println(getLocalName() + " received message from: " + msgReceive.getSender().getName());
					JSONObject obj = new JSONObject(msgReceive.getContent());
	
					try {
						// Check for which player the information will be updated and send
						if (obj.getJSONObject("player").getInt("playerID") == 1) {
							msgSend.setContentObject(updatePlayer(agentPlayer1, obj));
						} else {
							msgSend.setContentObject(updatePlayer(agentPlayer2, obj));
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
					
					// Send message to other agent
					msgSend.addReceiver(new AID("Planer", AID.ISLOCALNAME));
					send(msgSend);
					// if message is null, it will be blocked
				} else {
					block();
				}
			}
		});
	}
	
	protected void takeDown() {
		doSuspend();
		doActivate();
	}

	// Method to update or create Player class
	public Player updatePlayer(Player agentPlayer, JSONObject obj) {
		//If agentPlayer is not null, it will be updated
		if (agentPlayer != null) {
			agentPlayer.setLife(obj.getInt("life"));
			agentPlayer.setResource1(obj.getJSONObject("player").getInt("resource1"));
			agentPlayer.setResource2(obj.getJSONObject("player").getInt("resource2"));
			agentPlayer.setWorkerCount(obj.getJSONObject("player").getInt("workerCount"));
			agentPlayer.setUnitCount(obj.getJSONObject("player").getInt("unitCount"));
			agentPlayer.setUnitType1Count(obj.getJSONObject("player").getInt("unitType1Count"));
			agentPlayer.setUnitType2Count(obj.getJSONObject("player").getInt("unitType2Count"));
			agentPlayer.setUnitType3Count(obj.getJSONObject("player").getInt("unitType3Count"));
			agentPlayer.setUnitsLost(obj.getJSONObject("player").getInt("unitsLost"));
			agentPlayer.setBarrackCount(obj.getJSONObject("player").getInt("barrackCount"));
			agentPlayer.setBarracksLost(obj.getJSONObject("player").getInt("barracksLost"));
			agentPlayer.setGetsAttacked(obj.getJSONObject("player").getBoolean("getsAttacked"));
			agentPlayer.setAttacking(obj.getJSONObject("player").getBoolean("isAttacking"));
			agentPlayer.setAI(obj.getJSONObject("player").getBoolean("isAI"));
			agentPlayer.setHasCBR(obj.getJSONObject("player").getBoolean("hasCBR"));
			
			agentPlayer.setEnemyLife(obj.getInt("enemyLife"));
			agentPlayer.setEnemyWorkerCount(obj.getJSONObject("enemy").getInt("enemyWorkerCount"));
			agentPlayer.setEnemyUnitCount(obj.getJSONObject("enemy").getInt("enemyUnitCount"));
			agentPlayer.setEnemyUnitType1Count(obj.getJSONObject("enemy").getInt("enemyUnitType1Count"));
			agentPlayer.setEnemyUnitType2Count(obj.getJSONObject("enemy").getInt("enemyUnitType2Count"));
			agentPlayer.setEnemyUnitType3Count(obj.getJSONObject("enemy").getInt("enemyUnitType3Count"));
			agentPlayer.setEnemyBarrackCount(obj.getJSONObject("enemy").getInt("enemyBarrackCount"));
		//Else the class will be created
		} else {
			agentPlayer = new Player(obj.getJSONObject("player").getInt("playerID"), obj.getJSONObject("player").getInt("enemyID"), 
					obj.getJSONObject("player").getInt("life"), obj.getJSONObject("player").getInt("resource1"), 
					obj.getJSONObject("player").getInt("resource2"), obj.getJSONObject("player").getInt("workerCount"),
					obj.getJSONObject("player").getInt("unitCount"), obj.getJSONObject("player").getInt("unitType1Count"), 
					obj.getJSONObject("player").getInt("unitType2Count"), obj.getJSONObject("player").getInt("unitType3Count"), 
					obj.getJSONObject("player").getInt("barrackCount"), obj.getJSONObject("player").getInt("unitsLost"), 
					obj.getJSONObject("player").getInt("barracksLost"), obj.getJSONObject("player").getBoolean("getsAttacked"), 
					obj.getJSONObject("player").getBoolean("isAttacking"), obj.getJSONObject("player").getBoolean("isAI"), 
					obj.getJSONObject("player").getBoolean("hasCBR"),
					
					obj.getJSONObject("enemy").getInt("enemyLife"), obj.getJSONObject("enemy").getInt("enemyWorkerCount"), 
					obj.getJSONObject("enemy").getInt("enemyUnitCount"), obj.getJSONObject("enemy").getInt("enemyUnitType1Count"),
					obj.getJSONObject("enemy").getInt("enemyUnitType2Count"), obj.getJSONObject("enemy").getInt("enemyUnitType3Count"),
					obj.getJSONObject("enemy").getInt("enemyBarrackCount"));
		}
		return agentPlayer;
	}
}
