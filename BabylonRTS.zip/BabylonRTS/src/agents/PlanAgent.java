package agents;

import java.text.ParseException;

import org.json.JSONObject;

import cbr.CBREngine;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.UnreadableException;
import player.Player;

public class PlanAgent extends Agent {
	
	private CBREngine cbr;
	String bestCase;
	
	public PlanAgent() {
			try {
				this.cbr = new CBREngine();
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	protected void setup() {
		
		addBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				ACLMessage msgSend = new ACLMessage(ACLMessage.INFORM);
				ACLMessage msgReceive = myAgent.receive();
				Player agentPlayer = null;
				
				//Check if message is not null and contains a content block
				if(msgReceive != null && msgReceive.getContent() != null) {
					//JOptionPane.showMessageDialog(null, getLocalName() + " received: " + msg.getContent());
					System.out.println(getLocalName() + " received message from: " + msgReceive.getSender().getLocalName());
					
					try {
						//Get sent object
						agentPlayer = ((Player) msgReceive.getContentObject());
						
					} catch (UnreadableException e) {
						e.printStackTrace();
					}
					
					//Send generated plan
					msgSend.setContent(generatePlan(agentPlayer).toString());
					msgSend.addReceiver(new AID("Gamer", AID.ISLOCALNAME));
					send(msgSend);
				} else {
					block();
				}
			}
		});
	}
	
	protected void takeDown() {
	}
	
	//Function to get a plan for AI
	public JSONObject generatePlan(Player agentPlayer) {
		JSONObject plan = new JSONObject();
		
		//Receiving player attributes
		int playerID = agentPlayer.getPlayerId();
		int resource1 = agentPlayer.getResource1();
		int resource2 = agentPlayer.getResource2();
		int workerCount = agentPlayer.getWorkerCount();
		int unitCount = agentPlayer.getUnitCount();
		int unitType1Count = agentPlayer.getUnitType1Count();
		int unitType2Count = agentPlayer.getUnitType2Count();
		int unitType3Count = agentPlayer.getUnitType3Count();
		int barrackCount = agentPlayer.getBarrackCount();
		int life = agentPlayer.getLife();
		boolean getsAttacked = agentPlayer.isGetsAttacked();
		boolean isAttacking = agentPlayer.isAttacking();
		boolean hasCBR = agentPlayer.getHasCBR();
		
		int enemyLife = agentPlayer.getEnemyLife();
		int enemyWorkerCount = agentPlayer.getEnemyWorkerCount();
		int enemyUnitCount = agentPlayer.getEnemyUnitCount();
		int enemyUnitType1Count = agentPlayer.getEnemyUnitType1Count();
		int enemyUnitType2Count = agentPlayer.getEnemyUnitType3Count();
		int enemyUnitType3Count = agentPlayer.getEnemyUnitType3Count();
		int enemyBarrackCount = agentPlayer.getEnemyBarrackCount();
		
		
		//Check if agent is case-based
		if(hasCBR) {
			//Plan for case-based AI
			try {
				bestCase = cbr.createQueryInstance(isAttacking, getsAttacked, workerCount, unitCount, 
						unitType1Count, unitType2Count, unitType3Count, barrackCount, resource1, resource2, life,
						enemyLife, enemyWorkerCount, enemyUnitCount, enemyUnitType1Count, enemyUnitType2Count, enemyUnitType3Count,
						enemyBarrackCount);
				
				switch(bestCase) {
				case "gameStart":
					plan.put("nextStep", new JSONObject("{1:[worker,"+(5-workerCount)+"], 2:[barracks,"+(2-barrackCount)+"], 3:[fighter,5], 4:[attack,0]}"));
					break;
				case "getsAttacked":
					plan.put("nextStep", new JSONObject("{1:[fighterType3,5], 2:[attack,3]}"));
					break;
				case "lowFighter":
					plan.put("nextStep", new JSONObject("{1:[barracks,"+(1-barrackCount)+"], 2:[fighter,3]}"));
					break;
				case "lowWorker":
					plan.put("nextStep", new JSONObject("{1:[worker,"+(10-workerCount)+"]}"));
					break;
				case "lowLife":
					plan.put("nextStep", new JSONObject("{1:[fighterType3,3]}"));
					break;
				case "destroyBarrack":
					plan.put("nextStep", new JSONObject("{1:[fighterType1,"+(3-unitType1Count)+"], 2:[attack,2]}"));
					break;
				case "destroyWorker":
					plan.put("nextStep", new JSONObject("{1:[fighterType1,"+(unitType1Count-enemyWorkerCount)+"], 2:[attack,1]}"));
					break;
				case "destroyFighter1":
					plan.put("nextStep", new JSONObject("{1:[fighterType3,"+(enemyUnitType1Count-unitType3Count)+"], 2:[attack,30]}"));
					break;
				case "destroyFighter2":
					plan.put("nextStep", new JSONObject("{1:[fighterType1,"+(enemyUnitType2Count-unitType1Count)+"], 2:[attack,31]}"));
					break;
				case "destroyFighter3":
					plan.put("nextStep", new JSONObject("{1:[fighterType2,"+(enemyUnitType3Count-unitType2Count)+"], 2:[attack,32]}"));
					break;
				case "attack":
					plan.put("nextStep", new JSONObject("{1:[fighter,2], 2:[attack,0]}"));
					break;
				default:
					break;
				}
				plan.put("system", "cbr");
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else {
			//Plan for trivial AI
			//Top-Down priority: last command will overwrite the commands before
			//If player has under 5 fighting units: create more
			if(unitCount < 5) {
				plan.put("nextStep", "fighterType3");
				plan.put("count", (10-unitCount));
			} else {
				plan.put("nextStep", "attack");
				plan.put("count", unitCount);
			}
			//If player has under two barracks: create more
			if(barrackCount < 2) {
				plan.put("nextStep", "barracks");
				plan.put("count", (2-barrackCount));
			}
			//If player has under five worker: create more
			if(workerCount < 5) {
				plan.put("nextStep", "worker");
				plan.put("count", (5-workerCount));
			}
			plan.put("system", "trivial");
		}
		
		plan.put("playerID", playerID);
		return plan;
	}
}

