package csv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.json.JSONObject;

/**
 * Servlet implementation class CSVWriterServlet
 */
@WebServlet("/CSVWriterServlet")
public class CSVWriterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CSVWriterServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println(System.getProperty("user.dir"));
		System.out.println(System.getProperty("user.home"));
		System.out.println(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String currentTime = request.getParameter("currentTime");
		String timer = request.getParameter("timer");
		JSONObject player1 = null;
		JSONObject player2 = null;
		
		if(request.getParameter("player1") != null && request.getParameter("player2") != null) {
			player1 = new JSONObject(request.getParameter("player1"));
			player2 = new JSONObject(request.getParameter("player2"));
		}
		
		File theDir = new File(System.getProperty("user.home") + "/evaluation");
		File theDir1 = new File(System.getProperty("user.home") + "/evaluation/player1");
		File theDir2 = new File(System.getProperty("user.home") + "/evaluation/player2");
		
		createDirectory(theDir);
		createDirectory(theDir1);
		createDirectory(theDir2);
		
		csvWriter(theDir1, player1, currentTime, timer);
		csvWriter(theDir2, player2, currentTime, timer);
	}
	
	//This method creates a directory, if it doesn't already exists
	public void createDirectory(File theDir) {
		//System.out.println("Check Directory: " + theDir);
		// if the directory does not exist, create it
		if (!theDir.exists()) {
		    //System.out.println("creating directory: " + theDir.getName());
		    boolean result = false;
		    try{
		        theDir.mkdir();
		        result = true;
		    } 
		    catch(SecurityException se){
		        //handle it
		    }        
		    if(result) {    
		        //System.out.println("directory created");  
		    }
		}
	}
	
	//This method creates and writes or adds a csv file
	public void csvWriter(File theDir, JSONObject player, String currentTime, String timer) {
		 	String fileName = "statistics from " + currentTime + ".csv"; 
			String DELIMITER = ";";
			String NEW_LINE = "\n";
			String FILE_HEADER = "Time; Player; Life; Wood; Stone; Worker; Barracks; Fighter; FighterType1; FighterType2; FighterType3;";
			
			try {
				FileWriter fw = new FileWriter(theDir + "\\" + fileName, true);
				fw.append(FILE_HEADER);
				fw.append(NEW_LINE);
				fw.append(timer + DELIMITER);
				fw.append(player.getInt("playerID") + DELIMITER);			
				fw.append(player.getInt("life") + DELIMITER);
				fw.append(player.getInt("resource1") + DELIMITER);
				fw.append(player.getInt("resource2") + DELIMITER);
				fw.append(player.getInt("workerCount") + DELIMITER);
				fw.append(player.getInt("barrackCount") + DELIMITER);
				fw.append(player.getInt("unitCount") + DELIMITER);
				fw.append(player.getInt("unitType1Count") + DELIMITER);
				fw.append(player.getInt("unitType2Count") + DELIMITER);
				fw.append(player.getInt("unitType3Count") + DELIMITER);
				fw.append(NEW_LINE);
				fw.flush();
				fw.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}


