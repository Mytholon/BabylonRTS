package cbr;

import java.util.List;
import java.util.Map.Entry;

import de.dfki.mycbr.core.DefaultCaseBase;
import de.dfki.mycbr.core.Project;
import de.dfki.mycbr.core.casebase.Instance;
import de.dfki.mycbr.core.model.BooleanDesc;
import de.dfki.mycbr.core.model.Concept;
import de.dfki.mycbr.core.model.IntegerDesc;
import de.dfki.mycbr.core.model.StringDesc;
import de.dfki.mycbr.core.retrieval.Retrieval;
import de.dfki.mycbr.core.retrieval.Retrieval.RetrievalMethod;
import de.dfki.mycbr.core.similarity.IntegerFct;
import de.dfki.mycbr.core.similarity.Similarity;
import de.dfki.mycbr.core.similarity.config.NumberConfig;
import de.dfki.mycbr.util.Pair;


public class CaseBaseTest {


	public static void main (String[] args) {
		
		try {
			//Create a Project
			Project p = new Project();
			
			//Add casebase
			DefaultCaseBase cb = p.createDefaultCB("CaseBase");
			
			//Create concept
			Concept behavior = p.createTopConcept("Behavior");
			
			//Create retrieval		
			Retrieval r = new Retrieval(behavior, cb);
			//Specify retrieval method
			//available retrieval methods are: RETRIEVE , RETRIEVE_SORTED, RETRIEVE_K, RETRIEVE_K_SORTED
			r.setRetrievalMethod(RetrievalMethod.RETRIEVE);
			
			//Attribute Descriptions
			BooleanDesc getsAttacked = new BooleanDesc(behavior, "getsAttacked");
			BooleanDesc isAttacking = new BooleanDesc(behavior, "isAttacking");			
			IntegerDesc workerCount = new IntegerDesc(behavior, "workerCount", 20, 100);
			IntegerDesc fighterCount = new IntegerDesc(behavior, "fighterCount", 0, 100);
			IntegerDesc barrackCount = new IntegerDesc(behavior, "barrackCount", 0, 50);
			IntegerDesc resource1 = new IntegerDesc(behavior, "resource1Count", 0, 5000);
			IntegerDesc resource2 = new IntegerDesc(behavior, "resource2Count", 0, 5000);
			IntegerDesc life = new IntegerDesc(behavior, "buildingLife", 0, 1000);
			StringDesc plan = new StringDesc(behavior, "plan");
		
			//Attribute Functions
			IntegerFct workerFct = workerCount.addIntegerFct("workerCountFct", true);			
			workerFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
			IntegerFct fighterFct = fighterCount.addIntegerFct("fighterCountFct", true);			
			fighterFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
			IntegerFct barrackFct = barrackCount.addIntegerFct("barrackCountFct", true);
			barrackFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
			IntegerFct resource1Fct = resource1.addIntegerFct("resource1Fct", true);
			resource1Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
			IntegerFct resource2Fct = resource2.addIntegerFct("resource2Fct", true);
			resource2Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
			IntegerFct lifeFct = life.addIntegerFct("lifeFct", true);
			lifeFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
			
			//StringFct planFct = plan.addStringFct(StringConfig.EQUALITY, "planFct", false);
			
			//add cases
			Instance i1 = behavior.addInstance("lowResources");
			i1.addAttribute(isAttacking, false);
			i1.addAttribute(getsAttacked, false);
			i1.addAttribute(workerCount, 1);
			i1.addAttribute(fighterCount, 0);
			i1.addAttribute(barrackCount, 0);
			i1.addAttribute(resource1, 40);
			i1.addAttribute(resource2, 50);
			i1.addAttribute(life, 1000);
			
			Instance i2 = behavior.addInstance("lowWorker");
			i2.addAttribute(isAttacking, false);
			i2.addAttribute(getsAttacked, false);
			i2.addAttribute(workerCount, 2);
			i2.addAttribute(fighterCount, 0);
			i2.addAttribute(barrackCount, 1);
			i2.addAttribute(resource1, 250);
			i2.addAttribute(resource2, 150);
			i2.addAttribute(life, 1000);
			
			Instance i3 = behavior.addInstance("lowFighter");
			i3.addAttribute(isAttacking, false);
			i3.addAttribute(getsAttacked, false);
			i3.addAttribute(workerCount, 5);
			i3.addAttribute(fighterCount, 0);
			i3.addAttribute(barrackCount, 2);
			i3.addAttribute(resource1, 300);
			i3.addAttribute(resource2, 100);
			i3.addAttribute(life, 1000);
			
			Instance i4 = behavior.addInstance("gameStart");
			i4.addAttribute(isAttacking, false);
			i4.addAttribute(getsAttacked, false);
			i4.addAttribute(workerCount, 100);
			i4.addAttribute(fighterCount, 0);
			i4.addAttribute(barrackCount, 0);
			i4.addAttribute(resource1, 150);
			i4.addAttribute(resource2, 50);
			i4.addAttribute(life, 1000);
			i4.addAttribute(plan, "test");
			
			cb.addCase(i1);
			cb.addCase(i2);
			cb.addCase(i3);
			cb.addCase(i4);
			
			//Create a query instance to compare with casebase
			Instance query = r.getQueryInstance();
			query.addAttribute(isAttacking, false);
			query.addAttribute(getsAttacked, false);
			query.addAttribute(workerCount, 100);
			query.addAttribute(fighterCount, 0);
			query.addAttribute(barrackCount, 0);
			query.addAttribute(resource1, 150);
			query.addAttribute(resource2, 50);
			query.addAttribute(life, 1000);
						
			//Starting retrieval
			r.start();
			//Showing result in consol
			print(r);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//This method shows similarities with all cases and the best match
	private static void print(Retrieval r) {
		// get the retrieval result as a List
		List <Pair<Instance, Similarity>> result = r.getResult();
		if( result.size() > 0 ) {
			Double best = 0.0;
			int j = 0;
			for(int i = 0; i < result.size(); i++) {
				if(best < result.get(i).getSecond().getValue()) {
					best = result.get(i).getSecond().getValue();
					j = i;
				}
			}			
			String casename = result.get(j).getFirst().getName(); // get the case name
			Double sim = result.get(j).getSecond().getValue(); // get the similarity value
			String answer = "Best case "+ casename + " with a similarity of "+ sim + ".";
			System.out.println(answer);
		} else { System.out.println("Retrieval result is empty"); }
		
		for (Entry<Instance, Similarity> entry: r.entrySet()) {
			System.out.println("\nSimilarity: " + entry.getValue().getValue()
					+ " to case: " + entry.getKey());
		}
	}
}
