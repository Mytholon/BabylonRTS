package cbr;

import java.text.ParseException;
import java.util.List;

import de.dfki.mycbr.core.DefaultCaseBase;
import de.dfki.mycbr.core.Project;
import de.dfki.mycbr.core.casebase.Instance;
import de.dfki.mycbr.core.model.BooleanDesc;
import de.dfki.mycbr.core.model.Concept;
import de.dfki.mycbr.core.model.IntegerDesc;
import de.dfki.mycbr.core.model.StringDesc;
import de.dfki.mycbr.core.retrieval.Retrieval;
import de.dfki.mycbr.core.retrieval.Retrieval.RetrievalMethod;
import de.dfki.mycbr.core.similarity.IntegerFct;
import de.dfki.mycbr.core.similarity.Similarity;
import de.dfki.mycbr.core.similarity.config.NumberConfig;
import de.dfki.mycbr.util.Pair;

public class CBREngine {
	
	private Project p;
	private DefaultCaseBase cb;
	private Concept situation;
	private Retrieval r;
	private BooleanDesc getsAttacked;
	private BooleanDesc isAttacking;
	private IntegerDesc workerCount;
	private IntegerDesc fighterCount;
	private IntegerDesc fighterType1Count;
	private IntegerDesc fighterType2Count;
	private IntegerDesc fighterType3Count;
	private IntegerDesc barrackCount;
	private IntegerDesc resource1;
	private IntegerDesc resource2;
	private IntegerDesc life;
	private IntegerDesc enemyLife;
	private IntegerDesc enemyWorkerCount;
	private IntegerDesc enemyFighterCount;
	private IntegerDesc enemyFighterType1Count;
	private IntegerDesc enemyFighterType2Count;
	private IntegerDesc enemyFighterType3Count;
	private IntegerDesc enemyBarrackCount;
	
	public CBREngine() throws Exception {
		//Create a Project
		this.p = new Project();
		
		//Add casebase
		this.cb = p.createDefaultCB("CaseBase");
		
		//Create concept
		this.situation = p.createTopConcept("Situation");
		
		//Create retrieval	
		this.r = new Retrieval(situation, cb);
		//Specify retrieval method
		//available retrieval methods are: RETRIEVE , RETRIEVE_SORTED, RETRIEVE_K, RETRIEVE_K_SORTED
		r.setRetrievalMethod(RetrievalMethod.RETRIEVE);
		
		//Attribute Descriptions
		this.getsAttacked = new BooleanDesc(situation, "getsAttacked");
		this.isAttacking = new BooleanDesc(situation, "isAttacking");			
		this.workerCount = new IntegerDesc(situation, "workerCount", 0, 100);
		this.fighterCount = new IntegerDesc(situation, "fighterCount", 0, 100);
		this.fighterType1Count = new IntegerDesc(situation, "fighterType1", 0, 100);
		this.fighterType2Count = new IntegerDesc(situation, "fighterType2", 0, 100);
		this.fighterType3Count = new IntegerDesc(situation, "fighterType3", 0, 100);
		this.barrackCount = new IntegerDesc(situation, "barrackCount", 0, 20);
		this.resource1 = new IntegerDesc(situation, "resource1Count", 0, 100000);
		this.resource2 = new IntegerDesc(situation, "resource2Count", 0, 100000);
		this.life = new IntegerDesc(situation, "buildingLife", 0, 1000);
		this.enemyLife = new IntegerDesc(situation, "enemyBuildingLife", 0, 1000);
		this.enemyWorkerCount = new IntegerDesc(situation, "enemyWorkerCount", 0, 100);
		this.enemyFighterCount = new IntegerDesc(situation, "enemyFighterCount", 0, 200);
		this.enemyFighterType1Count = new IntegerDesc(situation, "enemyFighterType1", 0, 100);
		this.enemyFighterType2Count = new IntegerDesc(situation, "enemyFighterType2", 0, 100);
		this.enemyFighterType3Count = new IntegerDesc(situation, "enemyFighterType3", 0, 100);
		this.enemyBarrackCount = new IntegerDesc(situation, "enemyBarrackCount", 0, 20);
		
		//Attribute Functions
		IntegerFct workerFct = workerCount.addIntegerFct("workerCountFct", true);			
		workerFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct fighterFct = fighterCount.addIntegerFct("fighterCountFct", true);			
		fighterFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct fighter1Fct = fighterType1Count.addIntegerFct("fighter1CountFct", true);			
		fighter1Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct fighter2Fct = fighterType2Count.addIntegerFct("fighter2CountFct", true);			
		fighter2Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct fighter3Fct = fighterType3Count.addIntegerFct("fighter3CountFct", true);			
		fighter3Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct barrackFct = barrackCount.addIntegerFct("barrackCountFct", true);
		barrackFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct resource1Fct = resource1.addIntegerFct("resource1Fct", true);
		resource1Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct resource2Fct = resource2.addIntegerFct("resource2Fct", true);
		resource2Fct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct lifeFct = life.addIntegerFct("lifeFct", true);
		lifeFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyLifeFct = enemyLife.addIntegerFct("enemyLifeFct", true);
		enemyLifeFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyWorkerCountFct = enemyWorkerCount.addIntegerFct("enemyWorkerCountFct", true);
		enemyWorkerCountFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyFighterCountFct = enemyFighterCount.addIntegerFct("enemyFighterCountFct", true);
		enemyFighterCountFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyFighter1CountFct = enemyFighterType1Count.addIntegerFct("enemyFighter1CountFct", true);
		enemyFighter1CountFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyFighter2CountFct = enemyFighterType2Count.addIntegerFct("enemyFighter2CountFct", true);
		enemyFighter2CountFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyFighter3CountFct = enemyFighterType3Count.addIntegerFct("enemyFighter3CountFct", true);
		enemyFighter3CountFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		IntegerFct enemyBarrackCountFct = enemyBarrackCount.addIntegerFct("enemyBarrackCountFct", true);
		enemyBarrackCountFct.setFunctionTypeL(NumberConfig.POLYNOMIAL_WITH);
		
		//add cases
		Instance i1 = situation.addInstance("getsAttacked");
		i1.addAttribute(isAttacking, false);
		i1.addAttribute(getsAttacked, true);
		i1.addAttribute(workerCount, 5);
		i1.addAttribute(fighterCount, 0);
		i1.addAttribute(fighterType1Count, 0);
		i1.addAttribute(fighterType2Count, 0);
		i1.addAttribute(fighterType3Count, 0);
		i1.addAttribute(barrackCount, 2);
		i1.addAttribute(resource1, 150);
		i1.addAttribute(resource2, 50);
		i1.addAttribute(life, 950);
		i1.addAttribute(enemyLife, 1000);
		i1.addAttribute(enemyWorkerCount, 5);
		i1.addAttribute(enemyFighterCount, 5);
		i1.addAttribute(enemyFighterType1Count, 0);
		i1.addAttribute(enemyFighterType2Count, 0);
		i1.addAttribute(enemyFighterType3Count, 5);
		i1.addAttribute(enemyBarrackCount, 2);
				
		Instance i2 = situation.addInstance("lowWorker");
		i2.addAttribute(isAttacking, false);
		i2.addAttribute(getsAttacked, false);
		i2.addAttribute(workerCount, 0);
		i2.addAttribute(fighterCount, 3);
		i2.addAttribute(fighterType1Count, 1);
		i2.addAttribute(fighterType2Count, 1);
		i2.addAttribute(fighterType3Count, 1);
		i2.addAttribute(barrackCount, 2);
		i2.addAttribute(resource1, 150);
		i2.addAttribute(resource2, 50);
		i2.addAttribute(life, 1000);
		i2.addAttribute(enemyLife, 1000);
		i2.addAttribute(enemyWorkerCount, 5);
		i2.addAttribute(enemyFighterCount, 5);
		i2.addAttribute(enemyFighterType1Count, 0);
		i2.addAttribute(enemyFighterType2Count, 0);
		i2.addAttribute(enemyFighterType3Count, 5);
		i2.addAttribute(enemyBarrackCount, 2);
		
		Instance i3 = situation.addInstance("lowFighter");
		i3.addAttribute(isAttacking, false);
		i3.addAttribute(getsAttacked, false);
		i3.addAttribute(workerCount, 5);
		i3.addAttribute(fighterCount, 0);
		i3.addAttribute(fighterType1Count, 0);
		i3.addAttribute(fighterType2Count, 0);
		i3.addAttribute(fighterType3Count, 0);
		i3.addAttribute(barrackCount, 2);
		i3.addAttribute(resource1, 150);
		i3.addAttribute(resource2, 50);
		i3.addAttribute(life, 1000);
		i3.addAttribute(enemyLife, 1000);
		i3.addAttribute(enemyWorkerCount, 5);
		i3.addAttribute(enemyFighterCount, 5);
		i3.addAttribute(enemyFighterType1Count, 0);
		i3.addAttribute(enemyFighterType2Count, 0);
		i3.addAttribute(enemyFighterType3Count, 5);
		i3.addAttribute(enemyBarrackCount, 2);
				
		Instance i4 = situation.addInstance("gameStart");
		i4.addAttribute(isAttacking, false);
		i4.addAttribute(getsAttacked, false);
		i4.addAttribute(workerCount, 1);
		i4.addAttribute(fighterCount, 0);
		i4.addAttribute(fighterType1Count, 0);
		i4.addAttribute(fighterType2Count, 0);
		i4.addAttribute(fighterType3Count, 0);
		i4.addAttribute(barrackCount, 0);
		i4.addAttribute(resource1, 150);
		i4.addAttribute(resource2, 50);
		i4.addAttribute(life, 1000);
		i4.addAttribute(enemyLife, 1000);
		i4.addAttribute(enemyWorkerCount, 1);
		i4.addAttribute(enemyFighterCount, 0);
		i4.addAttribute(enemyFighterType1Count, 0);
		i4.addAttribute(enemyFighterType2Count, 0);
		i4.addAttribute(enemyFighterType3Count, 0);
		i4.addAttribute(enemyBarrackCount, 0);
		
		Instance i5 = situation.addInstance("lowLife");
		i5.addAttribute(isAttacking, false);
		i5.addAttribute(getsAttacked, false);
		i5.addAttribute(workerCount, 5);
		i5.addAttribute(fighterCount, 0);
		i5.addAttribute(fighterType1Count, 0);
		i5.addAttribute(fighterType2Count, 0);
		i5.addAttribute(fighterType3Count, 0);
		i5.addAttribute(barrackCount, 2);
		i5.addAttribute(resource1, 150);
		i5.addAttribute(resource2, 50);
		i5.addAttribute(life, 300);
		i5.addAttribute(enemyLife, 1000);
		i5.addAttribute(enemyWorkerCount, 5);
		i5.addAttribute(enemyFighterCount, 7);
		i5.addAttribute(enemyFighterType1Count, 2);
		i5.addAttribute(enemyFighterType2Count, 2);
		i5.addAttribute(enemyFighterType3Count, 3);
		i5.addAttribute(enemyBarrackCount, 2);
		
		Instance i6 = situation.addInstance("destroyBarrack");
		i6.addAttribute(isAttacking, false);
		i6.addAttribute(getsAttacked, false);
		i6.addAttribute(workerCount, 5);
		i6.addAttribute(fighterCount, 5);
		i6.addAttribute(fighterType1Count, 1);
		i6.addAttribute(fighterType2Count, 2);
		i6.addAttribute(fighterType3Count, 2);
		i6.addAttribute(barrackCount, 2);
		i6.addAttribute(resource1, 150);
		i6.addAttribute(resource2, 50);
		i6.addAttribute(life, 1000);
		i6.addAttribute(enemyLife, 1000);
		i6.addAttribute(enemyWorkerCount, 5);
		i6.addAttribute(enemyFighterCount, 9);
		i6.addAttribute(enemyFighterType1Count, 3);
		i6.addAttribute(enemyFighterType2Count, 3);
		i6.addAttribute(enemyFighterType3Count, 3);
		i6.addAttribute(enemyBarrackCount, 3);
		
		Instance i7 = situation.addInstance("destroyWorker");
		i7.addAttribute(isAttacking, false);
		i7.addAttribute(getsAttacked, false);
		i7.addAttribute(workerCount, 5);
		i7.addAttribute(fighterCount, 0);
		i7.addAttribute(fighterType1Count, 0);
		i7.addAttribute(fighterType2Count, 0);
		i7.addAttribute(fighterType3Count, 0);
		i7.addAttribute(barrackCount, 2);
		i7.addAttribute(resource1, 150);
		i7.addAttribute(resource2, 50);
		i7.addAttribute(life, 1000);
		i7.addAttribute(enemyLife, 1000);
		i7.addAttribute(enemyWorkerCount, 10);
		i7.addAttribute(enemyFighterCount, 5);
		i7.addAttribute(enemyFighterType1Count, 0);
		i7.addAttribute(enemyFighterType2Count, 0);
		i7.addAttribute(enemyFighterType3Count, 5);
		i7.addAttribute(enemyBarrackCount, 2);
		
		Instance i8 = situation.addInstance("destroyFighter1");
		i8.addAttribute(isAttacking, false);
		i8.addAttribute(getsAttacked, false);
		i8.addAttribute(workerCount, 5);
		i8.addAttribute(fighterCount, 9);
		i8.addAttribute(fighterType1Count, 3);
		i8.addAttribute(fighterType2Count, 3);
		i8.addAttribute(fighterType3Count, 3);
		i8.addAttribute(barrackCount, 2);
		i8.addAttribute(resource1, 150);
		i8.addAttribute(resource2, 50);
		i8.addAttribute(life, 1000);
		i8.addAttribute(enemyLife, 1000);
		i8.addAttribute(enemyWorkerCount, 5);
		i8.addAttribute(enemyFighterCount, 10);
		i8.addAttribute(enemyFighterType1Count, 8);
		i8.addAttribute(enemyFighterType2Count, 1);
		i8.addAttribute(enemyFighterType3Count, 1);
		i8.addAttribute(enemyBarrackCount, 3);
		
		Instance i9 = situation.addInstance("destroyFighter2");
		i9.addAttribute(isAttacking, false);
		i9.addAttribute(getsAttacked, false);
		i9.addAttribute(workerCount, 5);
		i9.addAttribute(fighterCount, 9);
		i9.addAttribute(fighterType1Count, 3);
		i9.addAttribute(fighterType2Count, 3);
		i9.addAttribute(fighterType3Count, 3);
		i9.addAttribute(barrackCount, 2);
		i9.addAttribute(resource1, 150);
		i9.addAttribute(resource2, 50);
		i9.addAttribute(life, 1000);
		i9.addAttribute(enemyLife, 1000);
		i9.addAttribute(enemyWorkerCount, 5);
		i9.addAttribute(enemyFighterCount, 10);
		i9.addAttribute(enemyFighterType1Count, 1);
		i9.addAttribute(enemyFighterType2Count, 8);
		i9.addAttribute(enemyFighterType3Count, 1);
		i9.addAttribute(enemyBarrackCount, 3);
		
		Instance i10 = situation.addInstance("destroyFighter3");
		i10.addAttribute(isAttacking, false);
		i10.addAttribute(getsAttacked, false);
		i10.addAttribute(workerCount, 5);
		i10.addAttribute(fighterCount, 9);
		i10.addAttribute(fighterType1Count, 3);
		i10.addAttribute(fighterType2Count, 3);
		i10.addAttribute(fighterType3Count, 3);
		i10.addAttribute(barrackCount, 2);
		i10.addAttribute(resource1, 150);
		i10.addAttribute(resource2, 50);
		i10.addAttribute(life, 1000);
		i10.addAttribute(enemyLife, 1000);
		i10.addAttribute(enemyWorkerCount, 5);
		i10.addAttribute(enemyFighterCount, 10);
		i10.addAttribute(enemyFighterType1Count, 1);
		i10.addAttribute(enemyFighterType2Count, 1);
		i10.addAttribute(enemyFighterType3Count, 8);
		i10.addAttribute(enemyBarrackCount, 3);
		
		Instance i11 = situation.addInstance("attack");
		i11.addAttribute(isAttacking, false);
		i11.addAttribute(getsAttacked, false);
		i11.addAttribute(workerCount, 5);
		i11.addAttribute(fighterCount, 3);
		i11.addAttribute(fighterType1Count, 1);
		i11.addAttribute(fighterType2Count, 1);
		i11.addAttribute(fighterType3Count, 1);
		i11.addAttribute(barrackCount, 1);
		i11.addAttribute(resource1, 150);
		i11.addAttribute(resource2, 50);
		i11.addAttribute(life, 1000);
		i11.addAttribute(enemyLife, 1000);
		i11.addAttribute(enemyWorkerCount, 5);
		i11.addAttribute(enemyFighterCount, 2);
		i11.addAttribute(enemyFighterType1Count, 0);
		i11.addAttribute(enemyFighterType2Count, 0);
		i11.addAttribute(enemyFighterType3Count, 2);
		i11.addAttribute(enemyBarrackCount, 1);
				
		cb.addCase(i1);
		cb.addCase(i2);
		cb.addCase(i3);
		cb.addCase(i4);
		cb.addCase(i5);
		cb.addCase(i6);
		cb.addCase(i7);
		cb.addCase(i8);
		cb.addCase(i9);
		cb.addCase(i10);
		cb.addCase(i11);
				
		System.out.println("CBR-System started and is ready");
	}
	
	public String createQueryInstance(boolean isAttacking, boolean getsAttacked, 
			int workerCount, int fighterCount, int fighterType1Count, int fighterType2Count, int fighterType3Count,
			int barrackCount, int resource1, int resource2, int life,
			int enemyLife, int enemyWorkerCount, int enemyUnitCount, int enemyUnitType1Count,
			int enemyUnitType2Count, int enemyUnitType3Count, int enemyBarrackCount) throws ParseException {
		
		//Create a query instance to compare with casebase
		Instance query = r.getQueryInstance();
		query.addAttribute(this.isAttacking, isAttacking);
		query.addAttribute(this.getsAttacked, getsAttacked);
		query.addAttribute(this.workerCount, workerCount);
		query.addAttribute(this.fighterCount, fighterCount);
		query.addAttribute(this.fighterType1Count, fighterType1Count);
		query.addAttribute(this.fighterType2Count, fighterType2Count);
		query.addAttribute(this.fighterType3Count, fighterType3Count);
		query.addAttribute(this.barrackCount, barrackCount);
		query.addAttribute(this.resource1, resource1);
		query.addAttribute(this.resource2, resource2);
		query.addAttribute(this.enemyLife, enemyLife);
		query.addAttribute(this.life, life);
		query.addAttribute(this.enemyWorkerCount, enemyWorkerCount);
		query.addAttribute(this.enemyFighterCount, enemyUnitCount);
		query.addAttribute(this.enemyFighterType1Count, enemyUnitType1Count);
		query.addAttribute(this.enemyFighterType2Count, enemyUnitType2Count);
		query.addAttribute(this.enemyFighterType3Count, enemyUnitType3Count);
		query.addAttribute(this.enemyBarrackCount, enemyBarrackCount);
		
		//Starting retrieval
		r.start();
		//Showing result in consol
		return print(r);
	}
	
	//This method shows similarities with all cases and the best match
	//returns name of best case
	private static String print(Retrieval r) {
		String casename = "";
		Double sim;
		String answer;
		
		// show all case similarities
//		for (Entry<Instance, Similarity> entry: r.entrySet()) {
//			System.out.println("Similarity: " + entry.getValue().getValue()
//					+ " to case: " + entry.getKey());
//		}
		
		// get the retrieval result as a List
		List <Pair<Instance, Similarity>> result = r.getResult();
		if( result.size() > 0 ) {
			Double best = 0.0;
			int j = 0;
			for(int i = 0; i < result.size(); i++) {
				if(best < result.get(i).getSecond().getValue()) {
					best = result.get(i).getSecond().getValue();
					j = i;
				}
			}			
			casename = result.get(j).getFirst().getName(); // get the case name
			sim = result.get(j).getSecond().getValue(); // get the similarity value
			answer = "Best case \""+ casename + "\" with a similarity of "+ sim + ".";
			System.out.println(answer);
			
		} else { 
			System.out.println("Retrieval result is empty"); 
		}
		return casename;
	}
}
